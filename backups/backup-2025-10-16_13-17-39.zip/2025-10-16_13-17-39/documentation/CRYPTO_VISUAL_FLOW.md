# 🔄 Crypto Purchase Flow - Visual Guide

## System Architecture

```
┌─────────────┐         ┌──────────────┐         ┌─────────────┐
│             │         │              │         │             │
│    USER     │────────▶│   STRIPE     │────────▶│  DATABASE   │
│             │         │   PAYMENT    │         │  (USD $$)   │
└─────────────┘         └──────────────┘         └─────────────┘
      │                                                  │
      │ Purchase Crypto                                 │
      ▼                                                  ▼
┌─────────────┐                                  ┌─────────────┐
│   PENDING   │                                  │  USD BALANCE│
│   ORDER     │◀─────────────────────────────────│  DEDUCTED   │
└─────────────┘                                  └─────────────┘
      │
      │ Admin Reviews
      ▼
┌─────────────┐         ┌──────────────┐         ┌─────────────┐
│             │         │              │         │             │
│   ADMIN     │────────▶│ SEND CRYPTO  │────────▶│    USER     │
│   PANEL     │         │ (MANUALLY)   │         │   WALLET    │
└─────────────┘         └──────────────┘         └─────────────┘
      │
      │ Mark Complete
      ▼
┌─────────────┐
│  ORDER      │
│  COMPLETED  │
└─────────────┘
```

## User Purchase Flow

```
┌──────────────────────────────────────────────────────────────┐
│                    USER JOURNEY                               │
└──────────────────────────────────────────────────────────────┘

Step 1: ADD USD FUNDS
┌─────────────────┐
│ User clicks     │
│ "Add Funds"     │
│                 │
│ Enters: $100    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Stripe Checkout │
│ (Card Payment)  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ ✅ SUCCESS      │
│ USD Balance:    │
│ $100            │
└─────────────────┘

Step 2: PURCHASE CRYPTO
┌─────────────────┐
│ User clicks     │
│ "Buy Crypto"    │
│                 │
│ Selects: BTC    │
│ Amount: $50     │
│ Wallet: 1A1z... │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ System          │
│ Calculates:     │
│                 │
│ Rate: $45,000   │
│ Fee: $1.25      │
│ Total: $51.25   │
│ BTC: 0.00111    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ ⚠️ PENDING      │
│ Order Created   │
│                 │
│ USD Balance:    │
│ $48.75          │
└─────────────────┘

Step 3: WAIT FOR ADMIN
┌─────────────────┐
│ ⏳ Waiting...  │
│                 │
│ Status: Pending │
│ Admin notified  │
└─────────────────┘

Step 4: RECEIVE CRYPTO
┌─────────────────┐
│ ✅ COMPLETED    │
│                 │
│ Received:       │
│ 0.00111 BTC     │
│                 │
│ TX: 0xabc123... │
└─────────────────┘
```

## Admin Process Flow

```
┌──────────────────────────────────────────────────────────────┐
│                   ADMIN WORKFLOW                              │
└──────────────────────────────────────────────────────────────┘

MORNING CHECK
┌─────────────────┐
│ Open Admin      │
│ Panel           │
│                 │
│ /admin/crypto   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ See Pending     │
│ Orders:         │
│                 │
│ 🔴 3 pending    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Order Details:  │
│                 │
│ User: john@...  │
│ BTC: 0.00111    │
│ Wallet: 1A1z... │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ VERIFY:         │
│ ✓ Amount OK     │
│ ✓ Wallet valid  │
│ ✓ User legit    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Open Coinbase/  │
│ Your Wallet     │
│                 │
│ Send: 0.00111   │
│ To: 1A1z...     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Get TX Hash:    │
│ 0xabc123...     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Update Order:   │
│                 │
│ Paste TX Hash   │
│ Click Complete  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ ✅ DONE!        │
│                 │
│ User notified   │
└─────────────────┘
```

## Withdrawal Request Flow

```
┌──────────────────────────────────────────────────────────────┐
│                WITHDRAWAL PROCESS                             │
└──────────────────────────────────────────────────────────────┘

USER REQUEST
┌─────────────────┐
│ User clicks     │
│ "Withdraw       │
│  Crypto"        │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Enter Details:  │
│                 │
│ Type: BTC       │
│ Amount: 0.005   │
│ Address: 1B2c...│
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ ⚠️ PENDING      │
│ Withdrawal      │
│ Requested       │
└─────────────────┘

ADMIN REVIEW
┌─────────────────┐
│ Admin sees      │
│ request         │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Verify:         │
│ ✓ User KYC?     │
│ ✓ Amount OK?    │
│ ✓ Wallet valid? │
│ ✓ No fraud?     │
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
    ▼         ▼
┌────────┐ ┌────────┐
│APPROVE │ │REJECT  │
└───┬────┘ └───┬────┘
    │          │
    ▼          ▼
┌────────┐ ┌────────┐
│Send    │ │Notify  │
│Crypto  │ │User    │
│        │ │        │
│Enter   │ │Reason: │
│TX Hash │ │"Amount │
└───┬────┘ │ too    │
    │      │ small" │
    ▼      └────────┘
┌────────┐
│✅ DONE │
└────────┘
```

## Database Flow

```
┌──────────────────────────────────────────────────────────────┐
│                  DATABASE OPERATIONS                          │
└──────────────────────────────────────────────────────────────┘

STRIPE PAYMENT
    │
    ▼
┌─────────────────┐
│ User.usdBalance │
│ +$100           │
└─────────────────┘
    │
    ▼
┌─────────────────┐
│ Transaction     │
│ type: "credit"  │
│ amount: $100    │
└─────────────────┘

CRYPTO PURCHASE
    │
    ▼
┌─────────────────┐
│ User.usdBalance │
│ -$51.25         │
└─────────────────┘
    │
    ▼
┌─────────────────┐
│ CryptoOrder     │
│ status: pending │
│ cryptoAmount:   │
│ 0.00111 BTC     │
└─────────────────┘
    │
    ▼
┌─────────────────┐
│ Transaction     │
│ type: "debit"   │
│ amount: -$51.25 │
└─────────────────┘

ADMIN COMPLETES
    │
    ▼
┌─────────────────┐
│ CryptoOrder     │
│ status:         │
│ completed       │
│ txHash:         │
│ 0xabc123...     │
└─────────────────┘
```

## Money Flow

```
┌──────────────────────────────────────────────────────────────┐
│                    MONEY & CRYPTO FLOW                        │
└──────────────────────────────────────────────────────────────┘

USER'S REAL MONEY
    │ $100 USD (credit card)
    ▼
┏━━━━━━━━━━━━━━━┓
┃    STRIPE     ┃ ◀─── Real payment processor
┗━━━━━━━━━━━━━━━┛
    │ $100 USD (minus Stripe fee ~$3)
    ▼
┏━━━━━━━━━━━━━━━┓
┃  YOUR BANK    ┃ ◀─── Your business account
┗━━━━━━━━━━━━━━━┛
    │ $97 USD (your profit)
    ▼
┏━━━━━━━━━━━━━━━┓
┃  YOUR CRYPTO  ┃ ◀─── Your Coinbase/wallet
┃   EXCHANGE    ┃
┗━━━━━━━━━━━━━━━┛
    │ Buy $50 BTC = 0.00111 BTC
    ▼
┏━━━━━━━━━━━━━━━┓
┃  USER'S       ┃ ◀─── Their personal wallet
┃  WALLET       ┃
┗━━━━━━━━━━━━━━━┛

YOUR DATABASE (Virtual Balance)
┌─────────────────────────────────┐
│ User USD Balance: $100          │ ◀─── Tracks their balance
│                                 │
│ After Purchase:                 │
│ User USD Balance: $48.75        │ ◀─── Deducted
│                                 │
│ You keep the difference:        │
│ $51.25 - $50 crypto =          │
│ $1.25 profit + fees            │ ◀─── Your margin
└─────────────────────────────────┘
```

## Status Flow

```
┌──────────────────────────────────────────────────────────────┐
│                   ORDER STATUS FLOW                           │
└──────────────────────────────────────────────────────────────┘

NEW ORDER
    │
    ▼
┌──────────┐
│ PENDING  │ ◀─── User just created order
└─────┬────┘
      │ Admin reviews
      ▼
┌──────────┐
│PROCESSING│ ◀─── Admin preparing to send
└─────┬────┘
      │ Admin sends crypto
      ▼
┌──────────┐
│COMPLETED │ ◀─── Crypto sent, TX hash recorded
└──────────┘

OR

┌──────────┐
│ PENDING  │
└─────┬────┘
      │ Admin decides not to send
      ▼
┌──────────┐
│CANCELLED │ ◀─── USD refunded to user
└──────────┘

WITHDRAWAL
    │
    ▼
┌──────────┐
│ PENDING  │ ◀─── User requests withdrawal
└─────┬────┘
      │
      ├─── Admin approves ───▶ ┌──────────┐
      │                        │ APPROVED │
      │                        └─────┬────┘
      │                              │ Admin sends
      │                              ▼
      │                        ┌──────────┐
      │                        │COMPLETED │
      │                        └──────────┘
      │
      └─── Admin rejects ───▶ ┌──────────┐
                              │ REJECTED │
                              └──────────┘
```

## Security Layers

```
┌──────────────────────────────────────────────────────────────┐
│                  SECURITY CHECKPOINTS                         │
└──────────────────────────────────────────────────────────────┘

LAYER 1: Stripe Payment
┌─────────────────────────────────────┐
│ ✓ Real credit card verification     │
│ ✓ Fraud detection                   │
│ ✓ 3D Secure (if enabled)            │
└─────────────────────────────────────┘
                │
                ▼
LAYER 2: USD Balance Check
┌─────────────────────────────────────┐
│ ✓ Sufficient balance?               │
│ ✓ Minimum purchase met?             │
│ ✓ Rate calculation correct?         │
└─────────────────────────────────────┘
                │
                ▼
LAYER 3: Admin Manual Review
┌─────────────────────────────────────┐
│ ✓ User legitimate?                  │
│ ✓ Wallet address valid?             │
│ ✓ Amount reasonable?                │
│ ✓ No suspicious pattern?            │
└─────────────────────────────────────┘
                │
                ▼
LAYER 4: Withdrawal Approval
┌─────────────────────────────────────┐
│ ✓ KYC verified?                     │
│ ✓ Withdrawal limit OK?              │
│ ✓ Address ownership verified?       │
│ ✓ No recent suspicious activity?    │
└─────────────────────────────────────┘
```

## Timeline Example

```
┌──────────────────────────────────────────────────────────────┐
│               TYPICAL ORDER TIMELINE                          │
└──────────────────────────────────────────────────────────────┘

09:00 AM │ User adds $100 via Stripe
         │ ✅ Payment successful
         │ ✅ USD balance updated
         │
09:15 AM │ User purchases $50 BTC
         │ ✅ Order created (pending)
         │ ✅ USD deducted
         │
10:00 AM │ Admin checks dashboard
         │ 📧 Sees pending order
         │
10:05 AM │ Admin reviews order
         │ ✓ Wallet address validated
         │ ✓ User account checked
         │
10:10 AM │ Admin sends BTC from Coinbase
         │ ⏳ Waiting for confirmation...
         │
10:25 AM │ Transaction confirmed
         │ ✅ TX Hash: 0xabc123...
         │
10:26 AM │ Admin marks order complete
         │ ✅ Order status: completed
         │ 📧 User notified
         │
10:30 AM │ User checks wallet
         │ 🎉 BTC received!
         │
         │ Total time: ~90 minutes
```

---

## Key Takeaways

✅ **User pays real money** → Stripe handles it
✅ **You receive the money** → Into your bank account
✅ **You buy crypto** → From your exchange (Coinbase, etc.)
✅ **You send crypto** → To user's wallet
✅ **You keep the difference** → Processing fees + profit margin

⚠️ **Manual Process** → You control every step (safer for beginners)
⚠️ **Admin Required** → Someone needs to process orders daily
⚠️ **Update Rates** → Crypto prices change constantly

🎉 **Simple & Safe** → Perfect for small to medium operations
🎉 **Full Control** → You approve everything before sending
🎉 **Low Risk** → Money secured before crypto purchased

---

**Ready to start?** Run the database migration and set your wallet addresses!
